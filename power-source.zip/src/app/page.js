// import React, { useEffect, useState } from "react";
// import * as echarts from "echarts";
// import axios from "axios";
// import ReactECharts from "echarts-for-react";

import EChartComponent from "@/components/BarChart";

// // /////////////////////////////////////////////////////////////////////////////
// // /////////////////////////////////////////////////////////////////////////////
// // /////////////////////////////////////////////////////////////////////////////

// const PowerSourceChart = () => {
//   return (
//     <div>
//       <h1 className="">E-Chart</h1>
//       <EChartComponent />
//     </div>
//   );
// };

// export default PowerSourceChart;

async function getData() {
  const res = await fetch(
    "https://api.thunder.softoo.co/vis/api/dashboard/ssu/fixed",
    { next: { revalidate: 5000 } }
  );
  // The return value is *not* serialized
  // You can return Date, Map, Set, etc.

  if (!res.ok) {
    // This will activate the closest `error.js` Error Boundary
    throw new Error("Failed to fetch data");
  }

  return res.json();
}

export default async function Page() {
  const data = await getData();
  console.log("Api data..>>>", data);

  return (
    <main>
      <h2>hellow E-chart</h2>
      <EChartComponent data={data} />
    </main>
  );
}
