"use client";
// import React from "react";
// import {
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   ResponsiveContainer,
//   Tooltip,
//   Label,
//   LabelList,
// } from "recharts";

// export const renderCustomizedLabel = (props) => {
//   const { content, ...rest } = props;
//   return <Label {...rest} fontSize="12" fill="#111" fontWeight="Bold" />;
// };

// function EChartComponent({ data: chartData }) {
// const [datachart, setdatachart] = useState([]);
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

// const EchartFTN = async () => {
//   console.log("EchartFTN is calling...");
//   let response = await axios.get(
//     "https://api.thunder.softoo.co/vis/api/dashboard/ssu/fixed"
//   );
//   console.log("This is process data:", response);
//   // setdatachart(response.data);
//   setdone(false);
// };

// useEffect(() => {
//   EchartFTN();
// }, []);

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

// useEffect(() => {
//   // Initialize ECharts instance
//   const chart = echarts?.init(document.getElementById("echarts-chart"));

//   // ECharts options
//   const option = {
//     tooltip: {
//       trigger: "axis",
//       axisPointer: {
//         // Use axis to trigger tooltip
//         type: "shadow", // 'shadow' as default; can also be 'line' or 'shadow'
//       },
//     },
//     legend: {},
//     grid: {
//       left: "3%",
//       right: "4%",
//       bottom: "3%",
//       containLabel: true,
//     },
//     xAxis: {
//       type: "value",
//     },
//     yAxis: {
//       type: "category",
//       data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
//     },
//     series: [
//       {
//         name: "Direct",
//         type: "bar",
//         stack: "total",
//         label: {
//           show: true,
//         },
//         emphasis: {
//           focus: "series",
//         },
//         data: [320, 302, 301, 334, 390, 330, 320],
//       },
//       {
//         name: "Mail Ad",
//         type: "bar",
//         stack: "total",
//         label: {
//           show: true,
//         },
//         emphasis: {
//           focus: "series",
//         },
//         data: [120, 132, 101, 134, 90, 230, 210],
//       },
//       {
//         name: "Affiliate Ad",
//         type: "bar",
//         stack: "total",
//         label: {
//           show: true,
//         },
//         emphasis: {
//           focus: "series",
//         },
//         data: [220, 182, 191, 234, 290, 330, 310],
//       },
//       {
//         name: "Video Ad",
//         type: "bar",
//         stack: "total",
//         label: {
//           show: true,
//         },
//         emphasis: {
//           focus: "series",
//         },
//         data: [150, 212, 201, 154, 190, 330, 410],
//       },
//       {
//         name: "Search Engine",
//         type: "bar",
//         stack: "total",
//         label: {
//           show: true,
//         },
//         emphasis: {
//           focus: "series",
//         },
//         data: [820, 832, 901, 934, 1290, 1330, 1320],
//       },
//     ],
//   };

//   // Set options and render the chart
//   chart?.setOption(option);

//   // Cleanup when unmounting
//   return () => {
//     chart?.dispose();
//   };
// }, []);

//   const data = [
//     {
//       date: "2023-09-16",
//       minute_window: "2023-09-16 00:00:00+05",
//       sourceTag: "Undetermined",
//     },
//     {
//       date: "2023-09-16",
//       minute_window: "2023-09-16 00:00:00+05",
//       sourceTag: "Undetermined",
//     },
//     {
//       date: "2023-09-16",
//       minute_window: "2023-09-16 00:00:00+05",
//       sourceTag: "Undetermined",
//     },
//     { name: "NE Send", completed: 230, failed: 335, inprogress: 453 },
//     { name: "NE Resend", completed: 335, failed: 330, inprogress: 345 },
//     {
//       name: "Miles Orchestrator",
//       completed: 537,
//       failed: 243,
//       inprogress: 2110,
//     },
//     {
//       name: "Commissions Payment Orch",
//       completed: 132,
//       failed: 328,
//       inprogress: 540,
//     },
//     {
//       name: "Business Integrators",
//       completed: 530,
//       failed: 145,
//       inprogress: 335,
//     },
//     { name: "SmartTrack", completed: 538, failed: 312, inprogress: 110 },
//   ];
//   console.log(chartData);

//   return (
//     <div>
//       <ResponsiveContainer height={250} width={"100%"}>
//         <BarChart
//           layout="vertical"
//           data={chartData?.data}
//           margin={{ left: 50, right: 50 }}
//           stackOffset="expand"
//         >
//           <XAxis hide type="number" />
//           <YAxis type="category" dataKey="date" stroke="#111" fontSize="12" />
//           <Tooltip />
//           <Bar dataKey="sourceTag" fill="#B798F5" stackId="a">
//             <LabelList
//               dataKey="sourceTag"
//               position="center"
//               content={renderCustomizedLabel}
//             />
//           </Bar>
//           {/* <Bar dataKey="completed" fill="#82ba7f" stackId="a">
//             <LabelList
//               dataKey="completed"
//               position="center"
//               content={renderCustomizedLabel}
//             />
//           </Bar>
//           <Bar dataKey="inprogress" fill="#76a8dd" stackId="a">
//             <LabelList
//               dataKey="inprogress"
//               position="center"
//               content={renderCustomizedLabel}
//             />
//           </Bar> */}
//         </BarChart>
//       </ResponsiveContainer>
//     </div>
//   );
// }

// export default EChartComponent;

import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  Label,
  LabelList,
} from "recharts";

export const renderCustomizedLabel = (props) => {
  const { content, ...rest } = props;
  return <Label {...rest} fontSize="12" fill="#111" fontWeight="Bold" />;
};

function EChartComponent({ data: chartData }) {
  // Create an object to map sourceTag values to their respective data arrays
  const sourceTagDataMap = {};

  chartData.data?.forEach((item) => {
    const { sourceTag, ...rest } = item;

    // Create an array for each unique sourceTag if it doesn't exist
    if (!sourceTagDataMap[sourceTag]) {
      sourceTagDataMap[sourceTag] = [];
    }

    sourceTagDataMap[sourceTag].push({ sourceTag, ...rest });
  });

  console.log(chartData);

  const data = Object.values(sourceTagDataMap);

  return (
    <div>
      <ResponsiveContainer height={250} width={"100%"}>
        <BarChart
          layout="vertical"
          data={data}
          margin={{ left: 50, right: 50 }}
          stackOffset="expand"
        >
          <XAxis hide type="number" />
          <YAxis type="category" dataKey="date" stroke="#111" fontSize="12" />
          <Tooltip />
          {Object.keys(sourceTagDataMap).map((sourceTag, index) => (
            <Bar
              key={sourceTag}
              dataKey={sourceTag}
              fill={`#${index + 1}a8dd`} // Provide a different color for each sourceTag
              stackId="a"
            >
              <LabelList
                dataKey={sourceTag}
                position="center"
                content={renderCustomizedLabel}
              />
            </Bar>
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export default EChartComponent;
